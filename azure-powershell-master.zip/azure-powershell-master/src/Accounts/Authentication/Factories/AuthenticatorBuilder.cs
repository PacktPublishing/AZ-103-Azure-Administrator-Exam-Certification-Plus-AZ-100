﻿// ----------------------------------------------------------------------------------
//
// Copyright Microsoft Corporation
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ----------------------------------------------------------------------------------
using Microsoft.Azure.Commands.Common.Authentication.Abstractions;
using System;

namespace Microsoft.Azure.Commands.Common.Authentication
{
    /// <summary>
    /// Default Factory for authentication
    /// </summary>
    public class AuthenticatorBuilder : IAuthenticatorBuilder
    {
        public static string AuthenticatorBuilderKey = nameof(AuthenticatorBuilder);
        static object lockObject = new object();

        public IAuthenticator Authenticator => new PassThroughAuthenticator();

        public bool AppendAuthenticator(Func<IAuthenticator> constructor)
        {
            var current = Authenticator;
            while (current?.Next != null)
            {
                current = current.Next;
            }

            if (current != null)
            {
                current.Next = constructor();
                return true;
            }

            return false;
        }

        private static IAuthenticatorBuilder Instance => new AuthenticatorBuilder();

        public static void Apply(IAzureSession session)
        {
            session.RegisterComponent<IAuthenticatorBuilder>(AuthenticatorBuilderKey, () => AuthenticatorBuilder.Instance);
        }
    }
}
