---
name: AzureRM module bug report
about: Report errors or unexpected behaviors for the AzureRM module
title: ''
labels: ''
assignees: ''

---

<!--

- The AzureRM module has been replaced by the Az module; please see the following document for more information:
    - https://docs.microsoft.com/en-us/powershell/azure/new-azureps-module-az
- If you are able to, please migrate to the Az module and see if the issue is reproducible
    - If so, please file an issue using the Az module template
- Please search the existing issues to see if there has been a similar issue filed

-->

## Description



## Steps to reproduce

```powershell

```

## Module versions

<!-- Please run (Get-Module -Name AzureRM* -ListAvailable) and paste the output in the below code block -->

```powershell

```

## Debug output

<!-- Set $DebugPreference='Continue' before running the repro and paste the resulting debug stream in the below code block -->

```

```

## Error output

<!-- Please run Resolve-AzureRmError and paste the output in the below code block -->

```

```
