---
name: Feature request
about: Suggest a new feature or improvement
title: ''
labels: Azure PS Team, Feature Request
assignees: ''

---

## Description of the new feature

## Proposed implementation details (optional)
