## Breaking Change Title

The following cmdlets were affected this release:

**Cmdlet-1**
- Description of what has changed

```powershell
# Old
# Sample of how the cmdlet was previously called

# New
# Sample of how the cmdlet should now be called
```

**Cmdlet-2**
- Description of what has changed

```powershell
# Old
# Sample of how the cmdlet was previously called

# New
# Sample of how the cmdlet should now be called
```

For an example migration guide for breaking changes, click [here](release-notes/migration-guide.2.0.0.md).
